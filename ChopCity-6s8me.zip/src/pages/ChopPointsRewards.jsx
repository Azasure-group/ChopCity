import React, { useState } from 'react';
import { useQuery, useAction, getUser, redeemPoints } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const ChopPointsRewardsPage = () => {
  const { data: user, isLoading, error } = useQuery(getUser);
  const redeemPointsFn = useAction(redeemPoints);
  const [pointsToRedeem, setPointsToRedeem] = useState(0);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleRedeemPoints = () => {
    redeemPointsFn({ userId: user.id, pointsToRedeem });
    setPointsToRedeem(0);
  };

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold'>Chop Points Rewards</h1>
      <p className='my-4'>Your Points: {user.points}</p>
      <div className='flex items-center gap-x-4 my-4'>
        <input
          type='number'
          placeholder='Points to Redeem'
          className='px-2 py-1 border rounded text-lg'
          value={pointsToRedeem}
          onChange={(e) => setPointsToRedeem(parseInt(e.target.value))}
        />
        <button
          onClick={handleRedeemPoints}
          className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'
        >
          Redeem Points
        </button>
      </div>
      <p className='text-sm text-gray-500'>Available Rewards: Check your rewards and points history below.</p>
    </div>
  );
};

export default ChopPointsRewardsPage;