import React from 'react';
import { useQuery, Link } from 'wasp/client/operations';

const MenuPage = () => {
  const { data: restaurant, isLoading, error } = useQuery(getRestaurant);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>{restaurant.name}</h1>
      <p className='text-lg mb-2'>{restaurant.cuisine}</p>
      <p className='mb-4'>{restaurant.rating} Stars | {restaurant.deliveryTime} mins</p>
      <h2 className='text-xl font-bold mb-2'>Menu</h2>
      {restaurant.menu.map((menuItem) => (
        <div key={menuItem.id} className='mb-4'>
          <h3 className='text-lg font-semibold'>{menuItem.name}</h3>
          <p className='mb-2'>{menuItem.description}</p>
          <p className='font-bold'>{menuItem.price}</p>
        </div>
      ))}
    </div>
  );
}

export default MenuPage;