import React from 'react';
import { useQuery, useAction } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const RestaurantListingsPage = () => {
  const { data: restaurants, isLoading, error } = useQuery(getRestaurants);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      {restaurants.map((restaurant) => (
        <div key={restaurant.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>{restaurant.name}</div>
          <div>{restaurant.cuisine}</div>
          <div>{restaurant.rating}</div>
          <div>{restaurant.deliveryTime} mins</div>
          <Link to={`/restaurants/${restaurant.id}`} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>View Menu</Link>
        </div>
      ))}
    </div>
  );
}

export default RestaurantListingsPage;