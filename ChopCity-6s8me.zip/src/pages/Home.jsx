import React, { useState } from 'react';
import { useQuery, getUser, getRestaurants } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const HomePage = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: restaurants, isLoading: restaurantsLoading, error: restaurantsError } = useQuery(getRestaurants);

  if (userLoading || restaurantsLoading) return 'Loading...';
  if (userError || restaurantsError) return 'Error: ' + (userError || restaurantsError);

  return (
    <div className='p-4'>
      <h1 className='text-3xl font-bold mb-4'>Welcome to ChopCity!</h1>
      <div className='grid grid-cols-2 gap-4'>
        <div>
          <h2 className='text-xl font-semibold mb-2'>Your Chop Points Balance:</h2>
          <p className='text-lg mb-4'>{user.points} Points</p>
        </div>
        <div>
          <input type='text' placeholder='Search for restaurants...' className='border rounded p-2 w-full mb-4' />
        </div>
      </div>
      <div className='grid grid-cols-3 gap-4'>
        {restaurants.map((restaurant) => (
          <Link key={restaurant.id} to={`/restaurants/${restaurant.id}`} className='bg-gray-100 p-4 rounded-lg'>
            <h3 className='text-lg font-semibold mb-2'>{restaurant.name}</h3>
            <p className='mb-2'>{restaurant.cuisine}</p>
            <p className='mb-2'>Rating: {restaurant.rating}</p>
            <p className='mb-2'>Delivery Time: {restaurant.deliveryTime} mins</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default HomePage;