import React from 'react';
import { Link } from 'wasp/client/router';
import { useQuery, useAction, getUser, addFavorite, removeFavorite } from 'wasp/client/operations';

const UserProfilePage = () => {
  const { data: user, isLoading, error } = useQuery(getUser);
  const addFavoriteFn = useAction(addFavorite);
  const removeFavoriteFn = useAction(removeFavorite);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleAddFavorite = (restaurantId) => {
    addFavoriteFn({ userId: user.id, restaurantId });
  };

  const handleRemoveFavorite = (restaurantId) => {
    removeFavoriteFn({ userId: user.id, restaurantId });
  };

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>User Profile</h1>
      <div className='mb-4'>
        <h2 className='text-xl font-bold mb-2'>Account Settings</h2>
        {/* Display account settings here */}
      </div>
      <div className='mb-4'>
        <h2 className='text-xl font-bold mb-2'>Payment Methods</h2>
        {/* Display payment methods here */}
      </div>
      <div className='mb-4'>
        <h2 className='text-xl font-bold mb-2'>Order History</h2>
        {/* Display order history here */}
      </div>
      <div className='mb-4'>
        <h2 className='text-xl font-bold mb-2'>Favorite Restaurants</h2>
        {user.favorites.map((restaurant) => (
          <div key={restaurant.id} className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'>
            <div>{restaurant.name}</div>
            <div>{restaurant.cuisine}</div>
            <div>
              <button onClick={() => handleRemoveFavorite(restaurant.id)} className='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded'>Remove</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default UserProfilePage;