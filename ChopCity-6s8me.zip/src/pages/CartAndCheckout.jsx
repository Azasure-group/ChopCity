import React from 'react';
import { useQuery, useAction, getUser, createOrder } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const CartAndCheckoutPage = () => {
  const { data: user, isLoading, error } = useQuery(getUser);
  const createOrderFn = useAction(createOrder);

  const handleCreateOrder = () => {
    createOrderFn();
  };

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <div>
        {/* Display User's cart, payment options, and apply rewards button */}
        <p>Display User's cart</p>
        <p>Payment options</p>
        <button onClick={handleCreateOrder} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>Place Order</button>
      </div>
    </div>
  );
}

export default CartAndCheckoutPage;