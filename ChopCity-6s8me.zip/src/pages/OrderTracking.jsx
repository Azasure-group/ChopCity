import React from 'react';
import { useQuery, getOrder } from 'wasp/client/operations';
import { Link } from 'wasp/client/router';

const OrderTrackingPage = () => {
  const { data: order, isLoading, error } = useQuery(getOrder);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Order Tracking</h1>
      <p>Order ID: {order.id}</p>
      <p>Status: {order.status}</p>
      <p>Total Price: ${order.totalPrice}</p>
      <p>Estimated Delivery Time: {order.deliveryTime} minutes</p>
      <Link to={`/orders/${order.id}`} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>View Details</Link>
    </div>
  );
}

export default OrderTrackingPage;