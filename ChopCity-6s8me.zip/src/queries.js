import { HttpError } from 'wasp/server'

export const getUser = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.User.findUnique({
    where: { id },
    include: {
      orders: {
        include: { menu: true }
      },
      favorites: {
        include: { menu: true }
      }
    }
  });
}

export const getRestaurants = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.Restaurant.findMany({
    include: { menu: true }
  });
}

export const getRestaurant = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const restaurant = await context.entities.Restaurant.findUnique({
    where: { id },
    include: { menu: true }
  });

  if (!restaurant) throw new HttpError(404, 'No restaurant with id ' + id);

  return restaurant;
}

export const getOrder = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const order = await context.entities.Order.findUnique({
    where: { id },
    include: {
      menu: true,
      user: true
    }
  });

  if (!order) throw new HttpError(404, 'No order with id ' + id);

  return order;
}