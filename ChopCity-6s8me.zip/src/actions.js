import { HttpError } from 'wasp/server'

export const createOrder = async ({ userId, menuItems, totalPrice }, context) => {
  if (!context.user) { throw new HttpError(401) };
  const user = await context.entities.User.findUnique({
    where: { id: userId },
    include: { menu: true }
  });
  if (!user) { throw new HttpError(400, 'User not found') };

  // Calculate new points based on the total value of the order
  const newPoints = Math.floor(totalPrice / 10);

  // Update user's points
  await context.entities.User.update({
    where: { id: userId },
    data: { points: { increment: newPoints } }
  });

  // Create the order
  return context.entities.Order.create({
    data: {
      userId,
      menu: {
        create: menuItems.map(item => ({
          name: item.name,
          description: item.description,
          price: item.price,
          restaurantId: item.restaurantId
        }))
      },
      totalPrice,
      status: 'Pending'
    }
  });
}

export const updateOrderStatus = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const order = await context.entities.Order.findUnique({
    where: { id: args.orderId }
  });
  if (!order) { throw new HttpError(404, 'Order not found') };

  return context.entities.Order.update({
    where: { id: args.orderId },
    data: { status: args.newStatus }
  });
}

export const redeemPoints = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  const user = await context.entities.User.findUnique({ where: { id: args.userId } });
  const updatedPoints = user.points - args.pointsToRedeem;
  return context.entities.User.update({ where: { id: args.userId }, data: { points: updatedPoints } });
}

export const addFavorite = async ({ userId, restaurantId }, context) => {
  if (!context.user) { throw new HttpError(401) };
  const user = await context.entities.User.findUnique({
    where: { id: userId }
  });
  if (!user) { throw new HttpError(404, 'User not found') };
  const restaurant = await context.entities.Restaurant.findUnique({
    where: { id: restaurantId }
  });
  if (!restaurant) { throw new HttpError(404, 'Restaurant not found') };
  return context.entities.User.update({
    where: { id: userId },
    data: {
      favorites: {
        connect: { id: restaurantId }
      }
    }
  });
}

export const removeFavorite = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  const user = await context.entities.User.findUnique({
    where: { id: args.userId }
  });
  if (!user) { throw new HttpError(404, 'User not found') };
  const restaurant = await context.entities.Restaurant.findUnique({
    where: { id: args.restaurantId }
  });
  if (!restaurant) { throw new HttpError(404, 'Restaurant not found') };
  const updatedUser = await context.entities.User.update({
    where: { id: args.userId },
    data: {
      favorites: {
        disconnect: { id: args.restaurantId }
      }
    }
  });
  return updatedUser;
}